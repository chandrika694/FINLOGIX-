from flask_migrate import Migrate
from .models import db  # assuming you import db from models